<?php

abstract class AbstractCallApiManager {
    public abstract function doOutgoingCall($number);
}