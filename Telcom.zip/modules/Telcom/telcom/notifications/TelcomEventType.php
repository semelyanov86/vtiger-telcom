<?php
class TelcomEventType {
    
    const INCOMING = 'incoming';
    const OUTGOING = 'outgoing';

    public const OUTGOING_TYPE = 'outbound';

    public const INCOMING_TYPE = 'inbound';

}
