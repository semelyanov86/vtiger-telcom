<?php

class ProvidersErrors
{
    const VALIDATE_REQUEST_ERROR = 1;
    const WRONG_PROVIDER_DATA = 2;
    const WRONG_SIGNATURE = 3;
}
