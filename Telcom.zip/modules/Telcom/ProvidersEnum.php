<?php
namespace Telcom;

class ProvidersEnum {
   
    const TELCOM = 'telcom';
}
