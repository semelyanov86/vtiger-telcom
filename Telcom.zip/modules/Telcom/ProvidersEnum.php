<?php

class ProvidersEnum
{
    const TELCOM = 'telcom';
}
