<?php

$languageStrings = array(
	'LBL_VOIP_PROVIDER_SETTINGS' => 'Settings',
    'LBL_DEFAULT_PROVIDER' => 'Default provider',
    'VoipIntegration' => 'Voip integration',
    'LBL_VOIP_PROVIDER_PARAMETERS' => 'Parameters',
    'LBL_SP_VOIP_SETTINGS' => 'Voip settings',
    'LBL_USE_CLICK_TO_CALL' => 'Use this provider for click2call',
);