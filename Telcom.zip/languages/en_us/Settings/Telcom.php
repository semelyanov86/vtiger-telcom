<?php

$languageStrings = array(
	'LBL_VOIP_PROVIDER_SETTINGS' => 'Settings',
    'LBL_DEFAULT_PROVIDER' => 'Default provider',
    'VoipIntegration' => 'Voip integration',
    'LBL_VOIP_PROVIDER_PARAMETERS' => 'Parameters',
    'LBL_SP_VOIP_SETTINGS' => 'Voip settings',
    'LBL_USE_CLICK_TO_CALL' => 'Use this provider for click2call',
    'LBL_USER_SYNCED' => 'User successfully synced!',
    'LBL_USER_VALIDATION_TITLE' => 'Enter all fields',
    'LBL_USER_VALIDATION_MESSAGE' => 'You should fill telcom ID and telcom password fields first'
);