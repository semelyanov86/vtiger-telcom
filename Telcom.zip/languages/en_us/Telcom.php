<?php

$languageStrings = array(
    'LBL_USER_SYNCED' => 'User successfully synced!',
    'LBL_USER_VALIDATION_TITLE' => 'Enter all fields',
    'LBL_USER_VALIDATION_MESSAGE' => 'You should fill telcom ID and telcom password fields first'
);